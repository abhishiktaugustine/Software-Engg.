<?php 
	#Any pHp code contains statements, expressions, functions, classes and objects as well as includes(External files)....
	
	function addFunc($first, $second)
	{
		return $first + $second;
	}
	function subFunc($first, $second)
	{
		return $first - $second;
	}
	function mulFunc($first, $second)
	{
		return $first * $second;
	}
	function divFunc($first, $second)
	{
		return $first / $second;
	}
 ?>