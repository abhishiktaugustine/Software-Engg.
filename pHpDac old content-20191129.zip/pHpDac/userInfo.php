<?php
#This class is used for the demo on sessions with objects...
	 class userInfo
	 {
	 	public $username;
	 	public $address;

	 	function __construct($name , $address)
	 	{
	 		$this->username = $name;
	 		$this->address = $address;
	 	}
	 } 
 ?>